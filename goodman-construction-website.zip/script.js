const header = document.querySelector('[data-header]');
const navToggle = document.querySelector('[data-nav-toggle]');
const nav = document.querySelector('[data-nav]');

const setHeader = () => header?.classList.toggle('scrolled', window.scrollY > 24);
setHeader();
window.addEventListener('scroll', setHeader, { passive: true });

navToggle?.addEventListener('click', () => {
  const isOpen = navToggle.getAttribute('aria-expanded') === 'true';
  navToggle.setAttribute('aria-expanded', String(!isOpen));
  nav?.classList.toggle('open', !isOpen);
  document.body.classList.toggle('menu-open', !isOpen);
});

document.querySelectorAll('.site-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    navToggle?.setAttribute('aria-expanded', 'false');
    nav?.classList.remove('open');
    document.body.classList.remove('menu-open');
  });
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px' });

document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));

const filterButtons = document.querySelectorAll('[data-filter]');
const galleryItems = document.querySelectorAll('.gallery-item');
filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.remove('active'));
    button.classList.add('active');
    galleryItems.forEach((item) => {
      const visible = filter === 'all' || item.dataset.category === filter;
      item.classList.toggle('hidden', !visible);
    });
  });
});

const lightbox = document.querySelector('[data-lightbox]');
const lightboxImage = document.querySelector('[data-lightbox-image]');
const lightboxTitle = document.querySelector('[data-lightbox-title]');

galleryItems.forEach((item) => {
  item.addEventListener('click', () => {
    if (!lightbox || !lightboxImage || !lightboxTitle) return;
    lightboxImage.src = item.dataset.image;
    lightboxImage.alt = item.querySelector('img')?.alt || '';
    lightboxTitle.textContent = item.dataset.title || '';
    lightbox.showModal();
    document.body.classList.add('lightbox-open');
  });
});

const closeLightbox = () => {
  lightbox?.close();
  document.body.classList.remove('lightbox-open');
};
document.querySelector('[data-lightbox-close]')?.addEventListener('click', closeLightbox);
lightbox?.addEventListener('click', (event) => {
  if (event.target === lightbox) closeLightbox();
});
lightbox?.addEventListener('close', () => document.body.classList.remove('lightbox-open'));

document.querySelector('[data-contact-form]')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const status = document.querySelector('[data-form-status]');
  const summary =
`GOODMAN CONSTRUCTION — PROJECT REQUEST

Name: ${data.get('name')}
Phone: ${data.get('phone')}
Email: ${data.get('email')}
Project type: ${data.get('project')}

Project details:
${data.get('message')}`;

  try {
    await navigator.clipboard.writeText(summary);
    if (status) {
      status.innerHTML = 'Project details copied. Call <a href="tel:+12819072808">281-907-2808</a> to discuss your estimate.';
    }
  } catch (error) {
    if (status) {
      status.textContent = 'Your project summary is ready. Please call 281-907-2808 to discuss your estimate.';
    }
  }
});

document.querySelectorAll('[data-year]').forEach((item) => {
  item.textContent = new Date().getFullYear();
});
